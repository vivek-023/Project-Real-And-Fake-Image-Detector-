from django.shortcuts import render
from django.http import HttpResponse
import cv2
import tensorflow as tf


model = tf.keras.models.load_model('model1.h5')
# Create your views here.
def index(request):
    
    # if request.method == 'POST':
        img = cv2.imread("./media/test.jpeg")
        res = model.predict(img)
        predicted_class = tf.argmax(res, axis=1)
        ans = predicted_class[0].numpy() 
        # 0 for fake 1 for real
        return HttpResponse(ans)
    # else:
        # return HttpResponse("Hello, world. You're at the polls index.")